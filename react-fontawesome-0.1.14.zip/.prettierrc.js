module.exports = {
  semi: false,
  singleQuote: true
}
